const express = require('express'); //importa el modulo express para crear el servidor
const path = require('path'); //importa el modulo path para manejar rutas de carpetas
const app = express(); //crea la aplicacion express
const PORT = 3000; //define el puerto en el que correra el servidor

//servir archivos estaticos desde la carpeta "public"
app.use(express.static(path.join(__dirname, '..', 'public'))); //permite servir archivos como html, css, js desde public

//ruta principal que sirve el archivo html
app.get('/', (req, res) => { //cuando el navegador pida la ruta '/', se envia el archivo html
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html')); //envia el archivo index.html al navegador
});

//iniciar el servidor
app.listen(PORT, () => { //el servidor empieza a escuchar en el puerto definido
  console.log(`Servidor corriendo en http://localhost:${PORT}`); //muestra un mensaje en consola para saber que esta corriendo
});


